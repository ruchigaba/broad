 import { Component, ViewEncapsulation } from '@angular/core';
// import { MessagingService} from "./messaging.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./common/common.scss'],
  encapsulation: ViewEncapsulation.None,
})
 export class AppComponent {



 }