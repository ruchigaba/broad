export const Stats: any[] = [
  {age: "6 weeks", population: 6},
  {age: "9 weeks", population: 9},
  {age: "3 weeks", population: 3},
];
export const Stats1: any[] = [
  {age: "15 weeks", population: 15},
  {age: "7 weeks", population: 7},
  {age: "4 weeks", population: 4},
];
export const Stats2: any[] = [
  {age: "12 weeks", population: 12},
  {age: "7 weeks", population: 7},
  {age: "5 weeks", population: 5},
];
